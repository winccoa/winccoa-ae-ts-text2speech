declare module 'winccoa-manager' {
  export enum WinccoaConnectUpdateType {}

  export class WinccoaError extends Error {}

  export class WinccoaManager {
    dpNames(dpPattern?: string, dpType?: string, ignoreCase?: boolean): string[];
    dpSetWait(dpeNames: string | string[], values: unknown | unknown[]): Promise<boolean>;
    dpConnect(
      callback: (
        dpeNames: string[],
        values: unknown[],
        type: WinccoaConnectUpdateType,
        error?: WinccoaError
      ) => void | Promise<void>,
      dpeNames: string | string[],
      answer?: boolean
    ): number;
  }

  export class WinccoaCtrlScript {
    constructor(manager: WinccoaManager, ctrlCode: string, name?: string);
    start(functionName?: string, functionParams?: unknown[]): Promise<unknown>;
  }
}
