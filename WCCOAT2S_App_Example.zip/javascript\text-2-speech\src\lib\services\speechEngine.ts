import { spawn } from 'node:child_process';
import { join } from 'node:path';

export interface SpeechEngine {
  speak(text: string, voice?: string, speed?: number): Promise<void>;
  getInstalledVoices(): Promise<string[]>;
}

interface ProcessResult {
  stdout: string;
  stderr: string;
}

const MAX_TEXT_LENGTH = 10_000;
const MAX_DIAGNOSTIC_LENGTH = 16_384;

function validateRequest(text: string, speed: number): void {
  if (typeof text !== 'string' || text.trim().length === 0) {
    throw new Error('Speech text must not be empty');
  }
  if (text.length > MAX_TEXT_LENGTH) {
    throw new Error(`Speech text exceeds the ${MAX_TEXT_LENGTH} character limit`);
  }
  if (!Number.isFinite(speed) || speed < 0.1 || speed > 3.0) {
    throw new Error('Speech speed must be between 0.1 and 3.0');
  }
}

function runProcess(command: string, args: string[], input?: string): Promise<ProcessResult> {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      shell: false,
      windowsHide: true,
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    let settled = false;

    const appendDiagnostic = (current: string, chunk: Buffer): string => {
      if (current.length >= MAX_DIAGNOSTIC_LENGTH) return current;
      return (current + chunk.toString('utf8')).slice(0, MAX_DIAGNOSTIC_LENGTH);
    };

    child.stdout.on('data', (chunk: Buffer) => {
      stdout = appendDiagnostic(stdout, chunk);
    });
    child.stderr.on('data', (chunk: Buffer) => {
      stderr = appendDiagnostic(stderr, chunk);
    });
    child.once('error', (error) => {
      if (settled) return;
      settled = true;
      reject(new Error(`Could not start ${command}: ${error.message}`, { cause: error }));
    });
    child.once('close', (code, signal) => {
      if (settled) return;
      settled = true;
      if (code === 0) {
        resolve({ stdout, stderr });
      } else {
        const reason = stderr.trim() || `exit code ${code}, signal ${signal ?? 'none'}`;
        reject(new Error(`${command} failed: ${reason}`));
      }
    });

    child.stdin.on('error', (error) => {
      if ((error as NodeJS.ErrnoException).code !== 'EPIPE' && !settled) {
        settled = true;
        reject(new Error(`Could not send input to ${command}: ${error.message}`, { cause: error }));
      }
    });
    child.stdin.end(input, 'utf8');
  });
}

const POWERSHELL_SPEAK_SCRIPT = String.raw`
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = [System.Text.UTF8Encoding]::new($false)
$request = [Console]::In.ReadToEnd() | ConvertFrom-Json
Add-Type -AssemblyName System.Speech
$synth = [System.Speech.Synthesis.SpeechSynthesizer]::new()
try {
  if ($request.voice) {
    $installed = @($synth.GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name })
    if ($installed -notcontains [string]$request.voice) {
      throw "The requested voice is not installed"
    }
    $synth.SelectVoice([string]$request.voice)
  }
  $synth.Rate = [int]$request.rate
  $synth.Speak([string]$request.text)
} finally {
  $synth.Dispose()
}
`;

const POWERSHELL_VOICES_SCRIPT = String.raw`
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
Add-Type -AssemblyName System.Speech
$synth = [System.Speech.Synthesis.SpeechSynthesizer]::new()
try {
  $voices = @($synth.GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name })
  [Console]::Out.Write((ConvertTo-Json -InputObject $voices -Compress))
} finally {
  $synth.Dispose()
}
`;

export class WindowsSpeechEngine implements SpeechEngine {
  private readonly powershell = join(
    process.env.SystemRoot ?? 'C:\\Windows',
    'System32',
    'WindowsPowerShell',
    'v1.0',
    'powershell.exe'
  );

  async speak(text: string, voice?: string, speed = 1.0): Promise<void> {
    validateRequest(text, speed);
    const rate = Math.max(-10, Math.min(10, Math.round(Math.log2(speed) * 4)));
    const request = JSON.stringify({ text, voice: voice || null, rate });

    await runProcess(
      this.powershell,
      ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', POWERSHELL_SPEAK_SCRIPT],
      request
    );
  }

  async getInstalledVoices(): Promise<string[]> {
    const { stdout } = await runProcess(
      this.powershell,
      ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', POWERSHELL_VOICES_SCRIPT]
    );
    const voices: unknown = JSON.parse(stdout || '[]');
    if (!Array.isArray(voices) || !voices.every((voice) => typeof voice === 'string')) {
      throw new Error('PowerShell returned an invalid voice list');
    }
    return voices;
  }
}

export class EspeakSpeechEngine implements SpeechEngine {
  private voices?: string[];

  async speak(text: string, voice?: string, speed = 1.0): Promise<void> {
    validateRequest(text, speed);
    const args = ['--stdin', '-s', String(Math.max(80, Math.min(450, Math.round(175 * speed))))];

    if (voice) {
      const installedVoices = this.voices ?? await this.getInstalledVoices();
      if (!installedVoices.includes(voice)) {
        throw new Error(`The requested eSpeak NG voice is not installed: ${voice}`);
      }
      args.push('-v', voice);
    }

    await runProcess('espeak-ng', args, text);
  }

  async getInstalledVoices(): Promise<string[]> {
    const { stdout } = await runProcess('espeak-ng', ['--voices']);
    const voices = stdout
      .split(/\r?\n/)
      .slice(1)
      .map((line) => line.trim().split(/\s+/)[4])
      .filter((voice): voice is string => Boolean(voice));

    this.voices = [...new Set(voices)].sort((a, b) => a.localeCompare(b));
    return this.voices;
  }
}

export function createSpeechEngine(platform = process.platform): SpeechEngine {
  if (platform === 'win32') return new WindowsSpeechEngine();
  if (platform === 'linux') return new EspeakSpeechEngine();
  throw new Error(`Text-to-speech is not supported on platform: ${platform}`);
}
