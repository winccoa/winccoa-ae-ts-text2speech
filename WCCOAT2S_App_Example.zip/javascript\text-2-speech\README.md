# Text-to-Speech JavaScript Manager

## Runtime requirements

- Node.js 22 or later.
- Windows: a supported and fully patched Windows installation, Windows PowerShell 5.1, and at least one installed `System.Speech` voice.
- Linux: a supported and fully patched Linux distribution with `espeak-ng` installed and available on `PATH`.

On Debian or Ubuntu, install the Linux speech engine with:

```sh
sudo apt install espeak-ng
```

For the five eSpeak NG memory-safety issues CVE-2023-49990 through CVE-2023-49994, use at least the package version supplied by the distribution security update:

- Debian 11: `1.50+dfsg-7+deb11u2`
- Debian 12: `1.51+dfsg-10+deb12u1`
- Ubuntu 20.04 LTS: `1.50+dfsg-6ubuntu0.1`
- Ubuntu 22.04 LTS: `1.50+dfsg-10ubuntu0.1`
- Ubuntu 24.04 LTS: not affected according to Ubuntu USN-6858-1

The application does not include or redistribute eSpeak NG. Voice names are platform-specific and must be selected from the voices reported by the configuration panel on the target system. Keep the operating system and eSpeak NG package updated through the distribution's security update mechanism.

## Build

```sh
npm install
npm run build
```
